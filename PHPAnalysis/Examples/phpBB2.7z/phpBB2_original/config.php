<?php


// phpBB 2.x auto-generated config file
// Do not change anything in this file!

$dbms = 'mysql';

$dbhost = 'localhost';
$dbname = 'phpbb2test';
$dbuser = 'phpbb2test';
$dbpasswd = 'phpbb2test';

$table_prefix = 'phpbb2test_';

define('PHPBB_INSTALLED', true);

?>